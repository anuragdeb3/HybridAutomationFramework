import pytesseract as tess
import cv2
import numpy as np
from PIL import Image


img = cv2.imread('C:\\Users\\anudeb\\Pictures\\payroll.PNG')


custom_config = r'--oem 3 --psm 6 outputbase digits'
print(tess.image_to_string(img, config=custom_config))




















