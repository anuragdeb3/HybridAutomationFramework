//here we are declaring the xpaths for different elements on the web page...
package merapack;
	
	public class constants {
        public static String URL="https://www.amazon.in/";
		public static String  uname="manish_madan1988@yahoo.com";
	    public static String  password="jaisairam";
	    public static String signin_flyout="//a[@id='nav-link-accountList']";
	  
	    		//"//*[@id='nav-link-yourAccount']/span[1]";
	    
	  
	    public static String  Sign_in= "//*[@id='nav-flyout-ya-signin']/a/span";
	    public static String Signin_btn="//*[@id='nav-flyout-ya-signin']/a/span";
	    public static String email="//input[@id='ap_email']";
	    public static String  cont="//input[@id='continue']";
	    public static String  pwd="//input[@id='ap_password']";
	    public static String  login_btn="//*[@id='signInSubmit']";
	    public static String remember="//input[@name='rememberMe']";
	    public static String search_box="//input[@id='twotabsearchtextbox']";
	    public static String search_lens="//*[@id='nav-search']/form/div[2]/div/input";
	    public static String item_to_pick="//*[@id='search']/div[1]/div[2]/div/span[3]/div[1]/div[7]/div/div/div/div[2]/div[2]/div/div[1]/h2/a";
	    public static String drpdwn="//select[@name='quantity']";
	    public static String addcart="//*[@id='add-to-cart-button']";	
	    public static String check_out="//*[@id='hlb-ptc-btn-native']";
	    public static String delivery_add="//*[@id='address-book-entry-1']/div[2]/span/a";
	    public static String cont_btn="//*[@id='shippingOptionFormId']/div/div[2]/div/span[1]/span/input";
	 // public static String card_radio="//*[@id='cbcc_banner']/a";
      public static String cvv="//*[@id='pp-Z2-135']";
	  public static String Cont_pymnt = "//*[@class='a-column a-span3 pmts-sidebar-wrapper a-span-last']/div[1]/div/div/span/span/input";
	
	}
	
