package merapack;
import java.util.ArrayList;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Utility {
	
	    public void set_up() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Manish\\eclipse-workspace\\chromedriver.exe");
		WebDriver wd= new ChromeDriver();
		JavascriptExecutor js= (JavascriptExecutor) wd;
		wd.navigate().to(constants.URL);
//		wd.manage().window().maximize();
		wd.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		WebElement e= wd.findElement(By.xpath(constants.signin_flyout));
		
		 Actions a = new Actions(wd);
		
		a.moveToElement(e).build().perform();
		wd.findElement(By.xpath(constants.Sign_in)).click();
		wd.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
		wd.findElement(By.xpath(constants.email)).sendKeys("8130437648");
		wd.findElement(By.xpath(constants.cont)).click();
		wd.findElement(By.xpath(constants.pwd)).sendKeys("jaisairam");
		wd.findElement(By.xpath(constants.remember)).click();
		wd.findElement(By.xpath(constants.login_btn)).click();
		wd.findElement(By.xpath(constants.search_box)).sendKeys("Men Cotton Socks");
		wd.findElement(By.xpath(constants.search_lens)).click();
		js.executeScript("window.scrollBy(0,1000)");
		wd.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		wd.findElement(By.xpath(constants.item_to_pick)).click();
		ArrayList <String> win_handles=new ArrayList<String>(wd.getWindowHandles());
		System.out.println(win_handles);
        wd.switchTo().window(win_handles.get(1));
		Select s= new Select(wd.findElement(By.xpath(constants.drpdwn)));
		wd.findElement(By.xpath(constants.drpdwn)).click();
		s.selectByVisibleText("2");
		try {
			Thread.sleep(2000);
		} catch (InterruptedException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		      }
		wd.findElement(By.xpath(constants.addcart)).click();
		wd.findElement(By.xpath(constants.check_out)).click();
		wd.findElement(By.xpath(constants.delivery_add)).click();
		wd.findElement(By.xpath(constants.cont_btn)).click();
		wd.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    js.executeScript("window.scrollBy(0,1200)");
	    //WebElement e2= wd.findElement(By.xpath(constants.card_radio));
	    //a.moveToElement(e2);
	    //wd.findElement(By.xpath(constants.card_radio)).click();
	    System.out.println("helloo....");
		
//		wd.findElement(By.xpath(constants.cvv)).sendKeys("897");
		
		wd.findElement(By.xpath(constants.Cont_pymnt)).click();
		ArrayList<String> windows=new ArrayList<String>(wd.getWindowHandles());
		wd.switchTo().window(windows.get(1));
		wd.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		wd.findElement(By.xpath(constants.cvv)).sendKeys("134");
		
		
		}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Utility u1 = new Utility();
       u1.set_up();
	}
}
